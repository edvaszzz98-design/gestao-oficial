package br.com.notacerta.controller;

import br.com.notacerta.dto.*;
import br.com.notacerta.model.*;
import br.com.notacerta.repository.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ApiController {
    private final StudentRepository students;
    private final SubjectRepository subjects;
    private final GradeRepository grades;

    public ApiController(StudentRepository students, SubjectRepository subjects, GradeRepository grades) {
        this.students = students; this.subjects = subjects; this.grades = grades;
    }

    @GetMapping("/health")
    public Map<String, String> health() { return Map.of("status", "ok", "service", "Sistema de Gestão de Notas API"); }

    @GetMapping("/students")
    public List<Student> listStudents() { return students.findAll(); }

    @PostMapping("/students")
    @ResponseStatus(HttpStatus.CREATED)
    public Student createStudent(@Valid @RequestBody StudentRequest request) {
        return students.save(new Student(request.name().trim(), request.email()));
    }

    @DeleteMapping("/students/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteStudent(@PathVariable Long id) {
        Student student = students.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aluno não encontrado."));
        grades.deleteAll(grades.findByStudentId(id));
        students.delete(student);
    }

    @GetMapping("/subjects")
    public List<Subject> listSubjects() { return subjects.findAll(); }

    @PostMapping("/subjects")
    @ResponseStatus(HttpStatus.CREATED)
    public Subject createSubject(@Valid @RequestBody SubjectRequest request) {
        return subjects.save(new Subject(request.name().trim()));
    }

    @DeleteMapping("/subjects/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteSubject(@PathVariable Long id) {
        Subject subject = subjects.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Disciplina não encontrada."));
        grades.deleteAll(grades.findAll().stream().filter(g -> g.getSubject().getId().equals(id)).toList());
        subjects.delete(subject);
    }

    @GetMapping("/grades")
    public List<Map<String, Object>> listGrades() {
        return grades.findAll().stream().map(this::gradeMap).toList();
    }

    @PostMapping("/grades")
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> createGrade(@Valid @RequestBody GradeRequest request) {
        Student student = students.findById(request.studentId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Aluno inválido."));
        Subject subject = subjects.findById(request.subjectId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Disciplina inválida."));
        return gradeMap(grades.save(new Grade(student, subject, request.score())));
    }

    @DeleteMapping("/grades/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteGrade(@PathVariable Long id) {
        grades.delete(grades.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Nota não encontrada.")));
    }

    @GetMapping("/students/{id}/summary")
    public Map<String, Object> summary(@PathVariable Long id) {
        Student student = students.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aluno não encontrado."));
        List<Map<String, Object>> summaries = subjects.findAll().stream().map(subject -> {
            List<Grade> list = grades.findByStudentIdAndSubjectId(id, subject.getId());
            Double average = list.isEmpty() ? null : list.stream().mapToDouble(Grade::getScore).average().orElse(0);
            String status = average == null ? "Sem notas" : average >= 7 ? "Aprovado" : average >= 5 ? "Recuperação" : "Reprovado";
            return Map.<String, Object>of("subjectId", subject.getId(), "subjectName", subject.getName(),
                "grades", list.stream().map(Grade::getScore).toList(),
                "average", average == null ? "" : average, "status", status);
        }).toList();
        return Map.of("student", student, "subjects", summaries);
    }

    private Map<String, Object> gradeMap(Grade grade) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", grade.getId());
        map.put("studentId", grade.getStudent().getId());
        map.put("studentName", grade.getStudent().getName());
        map.put("subjectId", grade.getSubject().getId());
        map.put("subjectName", grade.getSubject().getName());
        map.put("score", grade.getScore());
        map.put("createdAt", grade.getCreatedAt());
        return map;
    }
}
