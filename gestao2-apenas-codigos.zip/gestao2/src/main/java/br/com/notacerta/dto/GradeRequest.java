package br.com.notacerta.dto;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
public record GradeRequest(@NotNull Long studentId, @NotNull Long subjectId,
                           @NotNull @DecimalMin("0.0") @DecimalMax("10.0") Double score) {}
