package br.com.notacerta.dto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
public record StudentRequest(@NotBlank String name, @Email String email) {}
