package br.com.notacerta.dto;
import jakarta.validation.constraints.NotBlank;
public record SubjectRequest(@NotBlank String name) {}
