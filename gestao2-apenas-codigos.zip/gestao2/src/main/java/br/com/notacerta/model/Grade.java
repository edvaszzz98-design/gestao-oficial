package br.com.notacerta.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import java.time.LocalDateTime;

@Entity
@Table(name = "grades")
public class Grade {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Student student;

    @ManyToOne(optional = false)
    private Subject subject;

    @DecimalMin("0.0") @DecimalMax("10.0")
    @Column(nullable = false)
    private Double score;

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Grade() {}
    public Grade(Student student, Subject subject, Double score) {
        this.student = student; this.subject = subject; this.score = score;
        this.createdAt = LocalDateTime.now();
    }
    public Long getId() { return id; }
    public Student getStudent() { return student; }
    public Subject getSubject() { return subject; }
    public Double getScore() { return score; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
