package br.com.notacerta.repository;
import br.com.notacerta.model.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface GradeRepository extends JpaRepository<Grade, Long> {
    List<Grade> findByStudentId(Long studentId);
    List<Grade> findByStudentIdAndSubjectId(Long studentId, Long subjectId);
}
